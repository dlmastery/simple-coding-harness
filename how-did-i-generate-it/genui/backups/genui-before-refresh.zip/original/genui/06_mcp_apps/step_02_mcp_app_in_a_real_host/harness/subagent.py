"""Step 24 - the subagent loop, shared by task and browse, shows pictures too.

A task tool hands a self-contained exploration question to a fresh agent
that has its own context window. The subagent reuses call_llm: it takes a
list of messages and a tool set and returns one response.

Four rules, and the code below is really just these:

  1. it starts from an empty history           - none of the chat context
     the user had with the main agent is shared with the subagent
  2. it holds every tool but five              - task, browse, write_todos,
     str_replace and write_file are withheld; no recursion, one subagent deep
  3. it runs the same loop as the main agent   - call_llm, append, execute_all,
     and a tool result that carries an image marker becomes an image message
  4. only its final message.content comes back - none of the subagent's
     tool calls ever return to the main agent

The loop itself is loop(): a system prompt, a request, a tool set and a turn
cap. task() is one way to call it; browse.py is another.
"""

import os

import openai

MAX_TURNS = 12  # a runaway explorer is worse than a missing answer

# the computer tools too: an explorer reads and reports, it does not click - or write memories
WITHHELD = {"task", "browse", "write_todos", "str_replace", "write_file", "computer_act", "computer_screenshot", "remember", "forget"}

SYSTEM_PROMPT = f"""
You are an exploration subagent. You were given one question by a lead agent
and you answer it. That is the whole job.

You cannot see the conversation that spawned you, and the lead agent cannot
see anything you do here. Only your final message crosses back, so it has to
stand on its own.

You are working in {os.getcwd()}. Search inside it. Never search from / or
from the home directory - that scans the whole machine and will time out.

How to work:
- Use bash, read_file and read_skill to find out what is actually true.
  Prefer rg, grep and find to guess at where things live.
- You are here to read and report, not to change anything.
- Search in batches. Several greps in one turn beats one grep per turn.
- Stop as soon as you can answer. Do not keep looking to be thorough.

Your final message is the entire report, and it is the only thing that costs
the lead agent anything - so keep it short. Aim for under 150 words. Findings
only: file paths with line numbers, names, values. Say plainly what you could
not find; a gap is useful, a guess is not.
"""


def toolset():
    """Every tool schema except the withheld ones."""
    from .tools import TOOL_SCHEMAS

    return [s for s in TOOL_SCHEMAS if s["function"]["name"] not in WITHHELD]


def loop(system_prompt, request, tools, max_turns, label="subagent exploring"):
    """Run a fresh agent on one request and return only its final answer."""
    # Imported here, not at the top: tools imports us, and we need tools.
    from .history import fit, image_message, split_images
    from .llm import call_llm, entry
    from .tools import execute_all
    from .ui import ui

    allowed = {s["function"]["name"] for s in tools}  # what it may run == what it was shown

    # rule 1: two messages, born here, dead at the return
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": request},
    ]
    ui.subagent(request)
    report = None  # newest thing it has said, kept in case we run out of turns

    # rule 3: the loop from agent.py, pointed at a different list
    for _ in range(max_turns):
        fit(messages)  # its context can overflow too, and nobody compacts it

        try:
            with ui.working(label):
                message, usage = call_llm(messages, tools=tools)  # rule 2
        except (openai.APIError, RuntimeError) as failure:
            # its failure is a result for the main agent, never a crash of the session
            report = f"(the subagent's model call failed: {failure})" + (f"\n\nPartial findings:\n\n{report}" if report else "")
            return report
        messages.append(entry(message))
        ui.usage(usage)
        report = message.content or report

        # rule 4: no tool calls means it has stopped looking and started answering
        if not message.tool_calls:
            return report or "(the subagent came back with nothing)"

        # the same executor as the main loop: same permissions, same sandbox, same pool
        outcomes = execute_all(message.tool_calls, allowed)
        pictures = []
        for tool_call, (args, result) in zip(message.tool_calls, outcomes):
            result, paths = split_images(result)
            pictures += [(tool_call.function.name, path) for path in paths]
            ui.tool(tool_call.function.name, args, result, nested=True)
            messages.append({"role": "tool", "tool_call_id": tool_call.id, "content": result})
        for name, path in pictures:  # same expansion as agent.turn, after the last result
            messages.append(image_message(path, f"screenshot from tool {name}"))

    if report:
        return f"(stopped after {max_turns} turns, before finishing. Partial findings below.)\n\n{report}"
    return f"(stopped after {max_turns} turns with nothing to report.)"


def task(description: str) -> str:
    """The exploration subagent: every tool but the withheld ones, twelve turns."""
    return loop(SYSTEM_PROMPT, description, toolset(), MAX_TURNS)


TASK_SCHEMA = {
    "type": "function",
    "function": {
        "name": "task",
        "description": (
            "Hand a self-contained exploration question to a fresh agent that "
            "has its own context window, and get back its findings. Use this "
            "to learn how the codebase works - tracing behaviour, locating "
            "where something is implemented, surveying files - so the search "
            "costs you one answer instead of dozens of tool results. It cannot "
            "see this conversation, so include every detail it needs. It reads "
            "and reports; it never edits. Do your own editing."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "description": {
                    "type": "string",
                    "description": (
                        "The question, written to stand alone: what to find "
                        "out, where to start looking, and what the answer "
                        "should contain."
                    ),
                }
            },
            "required": ["description"],
        },
    },
}
