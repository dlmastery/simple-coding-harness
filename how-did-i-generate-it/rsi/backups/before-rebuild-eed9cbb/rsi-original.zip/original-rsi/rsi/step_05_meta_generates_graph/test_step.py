"""Lesson 05 - a meta skill generates the graph harness: the filled template is a legal graph pack; a cycle or an illegal\npath is refused before the human sees it; the writer lints, proposes, waits, and lands the human's edit.

Offline (seconds, no key, no agent): the pack contract - front matter, every file the procedure names
exists, no forbidden tool in the procedure, `.claude/skills` == `.agents/skills`, the hook line, the
intent files - plus this lesson's own claims. Live (`RSI_LIVE=1`): the recorded run, `claude -p` from
this directory with the README's prompt, then the assertions on the artifacts the skill must leave.
"""

import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

import pytest
import yaml

HERE = Path(__file__).resolve().parent
RSI = HERE.parent
SKILLS = HERE / ".claude" / "skills"
MIRROR = HERE / ".agents" / "skills"
RUNS = HERE / "runs"
PACKS = ['graph-writer']
INTENTS = ['../tasks/01_adult_income/intent.md']
CLAUDE_ARGS = ["--allowedTools", "Bash,Read,Write,Edit,Skill", "--setting-sources", "project", "--strict-mcp-config"]
RUNTIME_FILES = {"state.json", "traces.jsonl", "scorecard.json", "loop.log", "model.pkl", "curve.json", "exam.json", "score.json",
                 "plan.json", "working.md"}
FILE_RE = re.compile(r"`([\w./-]+\.(?:md|json|yaml|csv|jsonl))`")


# ---------------------------------------------------------------- reading packs


def front_matter(text):
    assert text.startswith("---\n"), "no front matter"
    head, body = text[4:].split("\n---\n", 1)
    return yaml.safe_load(head), body


def section(body, name):
    """The text under `## <name>` up to the next `## ` heading ("" when absent)."""
    m = re.search(rf"^## {re.escape(name)}\s*$", body, re.M)
    if not m:
        return ""
    rest = body[m.end():]
    nxt = re.search(r"^## ", rest, re.M)
    return rest[: nxt.start()] if nxt else rest


def forbidden_tools(tools_md):
    """The tool names under `## Forbidden`: each bullet is `name, name - why`."""
    out = []
    for line in section(tools_md, "Forbidden").splitlines():
        if line.startswith("- "):
            out += [t.strip().strip("`") for t in line[2:].split(" - ")[0].split(",")]
    return [t for t in out if t]


def tree(root):
    return {p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob("*") if p.is_file()}


def skill(pack):
    return front_matter((SKILLS / pack / "SKILL.md").read_text(encoding="utf-8"))


def rows(path):
    return [json.loads(l) for l in Path(path).read_text(encoding="utf-8").splitlines() if l.strip()]


def state(pack, task, arm):
    return json.loads((RUNS / pack / task / arm / "state.json").read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


# ---------------------------------------------------------------- the pack contract (every lesson)


@pytest.mark.parametrize("pack", PACKS)
def test_front_matter(pack):
    meta, body = skill(pack)
    assert meta["name"] == pack and meta["description"]
    assert set(meta["metadata"]) >= {"type", "version", "rsi"}
    for heading in ("Boot order", "Procedure", "Rules", "Done when"):
        assert f"## {heading}" in body, f"{pack}: no {heading}"


@pytest.mark.parametrize("pack", PACKS)
def test_procedure_names_existing_files(pack):
    """Every backticked file the SKILL.md names exists: in the pack, the lesson, or the series (../tasks, ../data)."""
    meta, body = skill(pack)
    for name in set(FILE_RE.findall(body)):
        if any(s in name for s in ("runs/", "<", "*", "helpers/", "proposals/", "versions/")) or re.match(r"[A-Z]/", name):
            continue
        if name.split("/")[-1] in RUNTIME_FILES or re.match(r"p\d{3}", name.split("/")[-1]):
            continue
        candidates = [SKILLS / pack / name, SKILLS / pack / "template" / name, HERE / name, RSI / name.lstrip("./"), SKILLS / name,
                      *(other / name for other in SKILLS.iterdir()), *(SKILLS / pack).rglob(Path(name).name),
                      *(p for p in HERE.glob(f"*/*/{Path(name).name}") if "runs" not in p.parts)]
        assert any(c.exists() for c in candidates), f"{pack}: SKILL.md names {name}, which does not exist"


@pytest.mark.parametrize("pack", PACKS)
def test_forbidden_tools_absent_from_procedure(pack):
    tools_md = (SKILLS / pack / "tools.md").read_text(encoding="utf-8")
    forbidden = forbidden_tools(tools_md)
    assert forbidden, f"{pack}: tools.md has no Forbidden list"
    procedure = section(skill(pack)[1], "Procedure")
    for name in forbidden:
        assert not re.search(rf"`{name}\b", procedure), f"{pack}: the procedure names `{name}`, which tools.md forbids"
    for name in forbidden:
        assert f"`{name}(" not in section(tools_md, "Allowed"), f"{pack}: {name} is both allowed and forbidden"


def test_mirror_identical():
    assert tree(SKILLS) == tree(MIRROR), ".claude/skills and .agents/skills differ"


def test_hook_installed():
    settings = json.loads((HERE / ".claude" / "settings.json").read_text(encoding="utf-8"))
    hooks = [h for entry in settings["hooks"]["PreToolUse"] if entry["matcher"] == "Bash" for h in entry["hooks"]]
    command = hooks[0]["command"]
    assert "score_test" in command and '"frozen": true' in command, "the hook does not gate score_test on FREEZE"
    assert "apply" in command and ".approved" in command, "the hook does not gate apply on an approval file"
    assert "exit 2" in command


def test_no_python_shipped():
    """The owner's rule: nothing under a lesson is Python except this file (runs/ is the agent's, not shipped)."""
    shipped = [p for p in HERE.rglob("*.py") if "runs" not in p.parts and "__pycache__" not in p.parts]
    assert [p.name for p in shipped] == ["test_step.py"], shipped


@pytest.mark.parametrize("intent", INTENTS)
def test_intent_contract(intent):
    meta, body = front_matter((HERE / intent).read_text(encoding="utf-8"))
    for key in ("name", "index", "title", "role", "target", "metric", "budget_fits", "models", "data", "test", "profile_keys"):
        assert key in meta, f"{intent}: front matter lacks {key}"
    assert meta["budget_fits"] == 24 and meta["test"] == "locked, scored once after FREEZE"
    assert meta["metric"] in ("roc_auc", "roc_auc_ovr_macro") and set(meta["models"]) <= {"logreg", "rf", "hgb"}
    assert meta["data"]["kind"] in ("csv", "sklearn", "synthetic")
    for heading in ("What to improve", "Why", "What counts as success", "What is off limits", "The profile the verifier may condition on"):
        assert f"## {heading}" in body, f"{intent}: body lacks {heading}"


# ---------------------------------------------------------------- this lesson's claims (offline)

TEMPLATE = SKILLS / "graph-writer" / "template"
FILL = {"task": "adult_income", "task_slug": "adult-income", "task_dir": "01_adult_income", "title": "Adult Census Income (> 50k)",
        "metric": "roc_auc", "budget_fits": "24"}


def filled():
    out = {}
    for p in TEMPLATE.iterdir():
        text = p.read_text(encoding="utf-8")
        for k, v in FILL.items():
            text = text.replace("{{" + k + "}}", v)
        out[p.name] = text
    return out


def lint_graph(graph, paths_file):
    """The DAG part of lint_pack as the contract states it; the list of problems."""
    problems = []
    edges = [tuple(e) for e in graph["edges"]] + [tuple(e) for e in paths_file.get("edges_added", [])]
    adj = {n: [b for a, b in edges if a == n] for n in graph["nodes"]}

    def cyclic(n, stack):
        if n in stack:
            return True
        return any(cyclic(m, stack | {n}) for m in adj.get(n, []))

    if any(cyclic(n, set()) for n in graph["nodes"]):
        problems.append("cycle")
    for p in paths_file["paths"]:
        steps = p["steps"]
        if any(n not in graph["nodes"] for n in steps):
            problems.append(f"{p['id']}: unknown node")
        elif any((a, b) not in set(edges) for a, b in zip(steps, steps[1:])):
            problems.append(f"{p['id']}: not an edge")
        for op in ("scale", "encode", "model"):
            if steps.count(op) != 1:
                problems.append(f"{p['id']}: one {op} per path")
        if "score_test" in steps:
            problems.append(f"{p['id']}: score_test as a step")
    return problems


def test_template_fills_into_a_legal_graph_pack():
    f = filled()
    assert sorted(f) == ["SKILL.md", "graph.json", "loop.json", "paths.json", "schema.json", "tools.md"] and "{{" not in "".join(f.values())
    graph, paths = json.loads(f["graph.json"]), json.loads(f["paths.json"])
    assert lint_graph(graph, paths) == [] and len(paths["paths"]) == 24
    intent = front_matter((RSI / "tasks" / "01_adult_income" / "intent.md").read_text(encoding="utf-8"))[0]
    schema, loop = json.loads(f["schema.json"]), json.loads(f["loop.json"])
    assert schema["n_fits"] == loop["N"] == intent["budget_fits"] and schema["test_rule"] == intent["test"]
    lesson_04 = RSI / "step_04_graph_harness" / ".claude" / "skills" / "adult-income-graph"
    assert (lesson_04 / "graph.json").read_text(encoding="utf-8") == f["graph.json"]


def test_bad_paths_are_refused_before_the_human():
    graph = json.loads(filled()["graph.json"])
    bad = json.loads((SKILLS / "graph-writer" / "bad_paths.json").read_text(encoding="utf-8"))
    problems = lint_graph(graph, bad)
    assert "cycle" in problems and any("one scale per path" in p for p in problems) and any("score_test as a step" in p for p in problems)


def test_writer_lints_before_it_proposes_and_lands_the_edit():
    procedure = section(skill("graph-writer")[1], "Procedure")
    assert procedure.index("`lint_pack") < procedure.index("`propose") < procedure.index("`apply")
    assert "bad_paths.json" in procedure and "--edited" in procedure and "approve / edit / reject" in procedure

# ---------------------------------------------------------------- the recorded run (RSI_LIVE=1)


def readme_prompt():
    """The prompt the README tells the reader to type: the first ```text block after "How to execute it"."""
    text = (HERE / "README.md").read_text(encoding="utf-8").split("## How to execute it", 1)[1]
    return re.search(r"```text\n(.*?)```", text, re.S).group(1).strip()


def reset():
    """Start from the shipped packs: on the first live run copy both mirrors to a pristine copy under the system temp
    directory (outside the agent's view), afterwards restore them from there; runs/ is cleared. The README says how to
    reset by hand."""
    pristine = Path(tempfile.gettempdir()) / "rsi_pristine" / HERE.name
    if not pristine.exists():
        pristine.mkdir(parents=True)
        shutil.copytree(SKILLS, pristine / ".claude")
        shutil.copytree(MIRROR, pristine / ".agents")
    if RUNS.exists():   # clear the run state but keep the recordings of earlier turns of this test
        for child in RUNS.iterdir():
            if child.name != "_recording":
                shutil.rmtree(child) if child.is_dir() else child.unlink()
    for root, src in ((SKILLS, ".claude"), (MIRROR, ".agents")):
        shutil.rmtree(root)
        shutil.copytree(pristine / src, root)
    for extra in ['.claude/skills/adult-income-graph', '.agents/skills/adult-income-graph']:
        if (HERE / extra).exists():
            shutil.rmtree(HERE / extra) if (HERE / extra).is_dir() else (HERE / extra).unlink()


def claude(prompt, cont=False, timeout=2400):
    """One `claude -p` turn from this directory; the stream is recorded under runs/_recording/, the final text returned."""
    exe = shutil.which("claude")
    assert exe, "claude is not on the PATH"
    args = [exe, "-p"] + (["--continue"] if cont else []) + [prompt, *CLAUDE_ARGS, "--output-format", "stream-json", "--verbose"]
    started = time.time()
    env = {k: v for k, v in os.environ.items() if k != "RSI_LIVE"}   # the recorded agent must not inherit the live switch
    proc = subprocess.run(args, cwd=HERE, capture_output=True, text=True, encoding="utf-8", errors="replace",
                          stdin=subprocess.DEVNULL, timeout=timeout, env=env)
    (RUNS / "_recording").mkdir(parents=True, exist_ok=True)
    n = len(list((RUNS / "_recording").glob("*.jsonl"))) + 1
    (RUNS / "_recording" / f"{n:02d}.jsonl").write_text(proc.stdout, encoding="utf-8")
    assert proc.returncode == 0, proc.stderr[-2000:]
    result = [o for o in (json.loads(l) for l in proc.stdout.splitlines() if l.startswith("{")) if o.get("type") == "result"]
    assert result and not result[-1].get("is_error"), proc.stdout[-2000:]
    print(f"[{result[-1]['num_turns']} turns, {int(time.time() - started)} s]")
    return result[-1]["result"]


def live_or_skip():
    if os.environ.get("RSI_LIVE") != "1":
        pytest.skip("set RSI_LIVE=1 to record the lesson with claude -p")


def test_live_claude_code():
    """The recorded run, two turns: the bad paths are refused and the proposal shown; `edit: remove path p24` lands 23 paths."""
    live_or_skip()
    reset()
    text = claude(readme_prompt())
    proposals = RUNS / "graph-writer" / "adult_income" / "proposals"
    assert (proposals / "p001.json").exists() and not (SKILLS / "adult-income-graph").exists()
    assert "cycle" in text.lower() and "approve" in text.lower()
    text2 = claude("edit: remove path p24", cont=True)
    landed = SKILLS / "adult-income-graph"
    assert (proposals / "p001.approved").read_text(encoding="utf-8").strip() == "edit: remove path p24"
    paths = json.loads((landed / "paths.json").read_text(encoding="utf-8"))["paths"]
    expected = [p for p in json.loads(filled()["paths.json"])["paths"] if p["id"] != "p24"]
    assert paths == expected and len(paths) == 23
    for name in ("SKILL.md", "graph.json", "loop.json", "schema.json", "tools.md"):
        assert (landed / name).read_text(encoding="utf-8") == filled()[name]
    assert tree(landed) == tree(MIRROR / "adult-income-graph")
    events = [r for r in rows(RUNS / "graph-writer" / "adult_income" / "traces.jsonl") if "event" in r]
    assert [e["event"] for e in events] == ["propose", "apply"] and events[-1]["approved"] == "edit: remove path p24"
